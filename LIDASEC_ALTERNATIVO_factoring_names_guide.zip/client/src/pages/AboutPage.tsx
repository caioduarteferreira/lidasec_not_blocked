import { Users, Target, Heart, Award, TrendingUp, Shield, ArrowLeft } from 'lucide-react';

export default function AboutPage() {
  const handleBackHome = () => {
    window.location.href = '/';
  };
  const values = [
    {
      icon: <Heart className="w-8 h-8" />,
      title: 'Confiança',
      description: 'Construímos relacionamentos baseados em transparência e integridade com todos os nossos clientes.',
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: 'Crescimento',
      description: 'Impulsionamos o crescimento sustentável dos negócios através de soluções inovadoras.',
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: 'Segurança',
      description: 'Protegemos os interesses financeiros de nossos clientes com máxima diligência.',
    },
    {
      icon: <Award className="w-8 h-8" />,
      title: 'Excelência',
      description: 'Buscamos a excelência em cada operação e interação com nossos parceiros.',
    },
  ];

  const team = [
    {
      name: 'Carlos Alberto Silva',
      role: 'Diretor Executivo',
      bio: 'Com 15+ anos de experiência em factoring, lidera a visão estratégica da empresa.',
      image: '/images/hero_background.png',
    },
    {
      name: 'Marina Costa Santos',
      role: 'Diretora de Operações',
      bio: 'Especialista em gestão de crédito e operações financeiras com expertise internacional.',
      image: '/images/section_business.png',
    },
    {
      name: 'Roberto Mendes',
      role: 'Gerente de Relacionamento',
      bio: 'Dedicado a entender e atender as necessidades únicas de cada cliente.',
      image: '/images/icon_speed.png',
    },
    {
      name: 'Fernanda Oliveira',
      role: 'Analista de Crédito',
      bio: 'Responsável pela análise rigorosa e aprovação rápida de operações.',
      image: '/images/icon_personalized.png',
    },
  ];

  const milestones = [
    { year: '2009', title: 'Fundação', description: 'lidasec é fundada com missão de revolucionar o factoring no Brasil' },
    { year: '2012', title: 'Expansão', description: 'Abrimos escritório em Santa Catarina e expandimos operações' },
    { year: '2015', title: 'Crescimento', description: 'Atingimos 200+ clientes ativos e R$ 20M em capital operacional' },
    { year: '2018', title: 'Inovação', description: 'Implementamos plataforma digital para facilitar operações' },
    { year: '2021', title: 'Consolidação', description: 'Alcançamos 500+ clientes e R$ 50M+ em capital operacional' },
    { year: '2024', title: 'Presente', description: 'Continuamos crescendo e inovando para servir melhor' },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Back Button */}
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="container mx-auto px-4 py-4">
          <button
            onClick={handleBackHome}
            className="flex items-center gap-2 text-green-600 hover:text-green-700 font-semibold transition-colors"
          >
            <ArrowLeft size={20} />
            Voltar para Home
          </button>
        </div>
      </div>
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-5xl font-bold mb-6">Sobre a lidasec</h1>
          <p className="text-xl text-green-100 max-w-2xl">
            Somos uma empresa especializada em factoring e fomento mercantil, dedicada a transformar as contas a receber em oportunidades de crescimento imediato.
          </p>
        </div>
      </div>

      {/* History Section */}
      <div className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Nossa História</h2>
              <p className="text-gray-700 mb-4 text-lg">
                A lidasec foi fundada em 2009 com uma visão clara: revolucionar o mercado de factoring no Brasil, tornando-o mais acessível, transparente e eficiente para empresas de todos os portes.
              </p>
              <p className="text-gray-700 mb-4 text-lg">
                Começamos com uma pequena equipe de profissionais apaixonados por finanças e inovação. Ao longo dos anos, crescemos significativamente, expandindo nossas operações e aprimorando continuamente nossas soluções.
              </p>
              <p className="text-gray-700 text-lg">
                Hoje, somos orgulhosos de servir mais de 500 clientes ativos, gerenciando mais de R$ 50 milhões em capital operacional. Nosso sucesso é resultado da confiança que nossos clientes depositam em nós.
              </p>
            </div>
            <div className="bg-gradient-to-br from-green-100 to-yellow-100 rounded-lg p-8 h-96 flex items-center justify-center">
              <img src="/images/hero_background.png" alt="História" className="w-full h-full object-cover rounded-lg" />
            </div>
          </div>
        </div>
      </div>

      {/* Mission and Vision */}
      <div className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Mission */}
            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-8 border-2 border-green-200">
              <div className="flex items-center gap-3 mb-4">
                <Target className="w-8 h-8 text-green-600" />
                <h3 className="text-2xl font-bold text-gray-900">Nossa Missão</h3>
              </div>
              <p className="text-gray-700 text-lg leading-relaxed">
                Ser o parceiro financeiro de confiança que impulsiona o crescimento sustentável dos negócios através de soluções de factoring ágeis, transparentes e personalizadas.
              </p>
            </div>

            {/* Vision */}
            <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg p-8 border-2 border-yellow-200">
              <div className="flex items-center gap-3 mb-4">
                <Users className="w-8 h-8 text-yellow-600" />
                <h3 className="text-2xl font-bold text-gray-900">Nossa Visão</h3>
              </div>
              <p className="text-gray-700 text-lg leading-relaxed">
                Ser reconhecida como a empresa de factoring mais confiável e inovadora do Brasil, oferecendo soluções que transformam a realidade financeira das empresas.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Values Section */}
      <div className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">Nossos Valores</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
                <div className="text-green-600 mb-4">{value.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Timeline Section */}
      <div className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">Nossa Jornada</h2>
          <div className="relative">
            {/* Timeline line */}
            <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-green-600 to-yellow-400"></div>

            {/* Timeline items */}
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className={`flex gap-8 ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
                  {/* Content */}
                  <div className="flex-1 md:w-1/2">
                    <div className={`bg-white rounded-lg shadow-md p-6 ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>
                      <span className="inline-block px-4 py-2 bg-green-100 text-green-700 font-bold rounded-full mb-3">
                        {milestone.year}
                      </span>
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">{milestone.title}</h3>
                      <p className="text-gray-600">{milestone.description}</p>
                    </div>
                  </div>

                  {/* Timeline dot */}
                  <div className="hidden md:flex w-0 justify-center">
                    <div className="w-4 h-4 bg-green-600 rounded-full border-4 border-white"></div>
                  </div>

                  {/* Spacer */}
                  <div className="flex-1 md:w-1/2"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Team Section */}
      <div className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">Nossa Equipe</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="h-48 overflow-hidden bg-gray-200">
                  <img src={member.image} alt={member.name} className="w-full h-full object-cover" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{member.name}</h3>
                  <p className="text-green-600 font-semibold mb-3">{member.role}</p>
                  <p className="text-gray-600 text-sm">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-5xl font-bold mb-2">500+</div>
              <p className="text-green-100 text-lg">Clientes Ativos</p>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">R$ 50M+</div>
              <p className="text-green-100 text-lg">Capital Operacional</p>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">15+</div>
              <p className="text-green-100 text-lg">Anos de Experiência</p>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">98%</div>
              <p className="text-green-100 text-lg">Satisfação de Clientes</p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">Faça Parte da Nossa História</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Se você está buscando um parceiro confiável para impulsionar o crescimento do seu negócio, estamos aqui para ajudar.
          </p>
          <a href="/#contato" className="inline-block px-8 py-4 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700 transition-colors">
            Entre em Contato
          </a>
        </div>
      </div>
    </div>
  );
}
