import { useParams, Link } from 'wouter';
import { getBlogArticleBySlug, blogArticles } from '@/data/blogArticles';
import { Calendar, Clock, User, ArrowLeft, Share2 } from 'lucide-react';
import { Streamdown } from 'streamdown';

export default function BlogArticlePage() {
  const { slug } = useParams<{ slug: string }>();
  const article = slug ? getBlogArticleBySlug(slug) : undefined;

  const handleBackHome = () => {
    window.location.href = '/';
  };

  if (!article) {
    return (
      <div className="min-h-screen bg-white">
        {/* Back Button */}
        <div className="bg-gray-50 border-b border-gray-200">
          <div className="container mx-auto px-4 py-4">
            <button
              onClick={handleBackHome}
              className="flex items-center gap-2 text-green-600 hover:text-green-700 font-semibold transition-colors"
            >
              <ArrowLeft size={20} />
              Voltar para Home
            </button>
          </div>
        </div>
        <div className="flex items-center justify-center min-h-[calc(100vh-80px)]">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Artigo não encontrado</h1>
          <p className="text-gray-600 mb-8">Desculpe, o artigo que você procura não existe.</p>
          <Link href="/blog" className="inline-block px-6 py-3 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700">
            Voltar ao Blog
          </Link>
        </div>
      </div>
      </div>
    );
  }

  const relatedArticles = blogArticles
    .filter((a) => a.category === article.category && a.id !== article.id)
    .slice(0, 3);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Back to Home Button */}
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="container mx-auto px-4 py-4">
          <button
            onClick={handleBackHome}
            className="flex items-center gap-2 text-green-600 hover:text-green-700 font-semibold transition-colors"
          >
            <ArrowLeft size={20} />
            Voltar para Home
          </button>
        </div>
      </div>

      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/blog" className="flex items-center gap-2 text-green-600 hover:text-green-700 font-semibold">
            <ArrowLeft size={20} />
            Voltar ao Blog
          </Link>
          <button className="flex items-center gap-2 text-gray-600 hover:text-gray-900">
            <Share2 size={20} />
            Compartilhar
          </button>
        </div>
      </div>

      {/* Hero Image */}
      <div className="relative h-96 overflow-hidden bg-gray-200">
        <img src={article.image} alt={article.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/30"></div>
      </div>

      {/* Article Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Title and Meta */}
            <div className="mb-8">
              <div className="flex items-center gap-3 mb-4">
                <span className="inline-block px-3 py-1 bg-green-100 text-green-700 text-sm font-semibold rounded-full">
                  {article.category}
                </span>
              </div>

              <h1 className="text-5xl font-bold text-gray-900 mb-6">{article.title}</h1>

              <div className="flex flex-wrap items-center gap-6 text-gray-600 pb-6 border-b border-gray-200">
                <span className="flex items-center gap-2">
                  <User size={18} />
                  {article.author}
                </span>
                <span className="flex items-center gap-2">
                  <Calendar size={18} />
                  {formatDate(article.date)}
                </span>
                <span className="flex items-center gap-2">
                  <Clock size={18} />
                  {article.readTime} min de leitura
                </span>
              </div>
            </div>

            {/* Article Body */}
            <div className="prose prose-lg max-w-none mb-12">
              <Streamdown>{article.content}</Streamdown>
            </div>

            {/* Share Section */}
            <div className="bg-gradient-to-r from-green-50 to-yellow-50 rounded-lg p-8 border border-green-200">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Gostou deste artigo?</h3>
              <p className="text-gray-700 mb-6">
                Compartilhe com seus colegas e continue acompanhando nosso blog para mais conteúdo educativo sobre factoring e gestão financeira.
              </p>
              <div className="flex gap-4">
                <button className="px-6 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2">
                  <Share2 size={18} />
                  Compartilhar
                </button>
                <Link href="/blog" className="px-6 py-3 bg-white text-green-600 font-semibold rounded-lg border-2 border-green-600 hover:bg-green-50 transition-colors">
                  Voltar ao Blog
                </Link>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* CTA Box */}
            <div className="bg-gradient-to-br from-green-600 to-green-700 text-white rounded-lg p-6 mb-8 sticky top-24">
              <h3 className="text-xl font-bold mb-3">Pronto para crescer?</h3>
              <p className="text-green-100 text-sm mb-6">
                Descubra como nossas soluções de factoring podem transformar seu negócio.
              </p>
              <a href="/#contato" className="block w-full px-4 py-3 bg-yellow-400 text-gray-900 font-bold rounded-lg hover:bg-yellow-500 transition-colors text-center">
                Solicitar Contato
              </a>
            </div>

            {/* Related Articles */}
            {relatedArticles.length > 0 && (
              <div className="bg-white rounded-lg border border-gray-200 p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Artigos Relacionados</h3>
                <div className="space-y-4">
                  {relatedArticles.map((relatedArticle) => (
                    <Link key={relatedArticle.id} href={`/blog/${relatedArticle.slug}`}>
                      <div className="group cursor-pointer">
                        <h4 className="font-semibold text-gray-900 group-hover:text-green-600 transition-colors line-clamp-2 text-sm">
                          {relatedArticle.title}
                        </h4>
                        <p className="text-xs text-gray-500 mt-1">{relatedArticle.readTime} min de leitura</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* More Articles Section */}
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Mais Artigos do Blog</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {blogArticles.slice(0, 3).map((a) => (
              <Link key={a.id} href={`/blog/${a.slug}`}>
                <div className="group bg-white rounded-lg shadow-md hover:shadow-lg transition-all cursor-pointer overflow-hidden border border-gray-200 hover:border-green-400">
                  <div className="h-48 overflow-hidden bg-gray-200">
                    <img src={a.image} alt={a.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                  </div>
                  <div className="p-4">
                    <span className="inline-block px-2 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded mb-2">
                      {a.category}
                    </span>
                    <h3 className="font-bold text-gray-900 group-hover:text-green-600 transition-colors line-clamp-2 mb-2">
                      {a.title}
                    </h3>
                    <p className="text-sm text-gray-600 line-clamp-2 mb-4">{a.excerpt}</p>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{a.readTime} min</span>
                      <span>{formatDate(a.date)}</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
