import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import DiferenciaisSection from '@/components/DiferenciaisSection';
import InstitucionalSection from '@/components/InstitucionalSection';
import ServicosSection from '@/components/ServicosSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <HeroSection />
      <DiferenciaisSection />
      <InstitucionalSection />
      <ServicosSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
