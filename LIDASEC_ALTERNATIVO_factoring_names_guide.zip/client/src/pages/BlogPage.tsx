import BlogList from '@/components/BlogList';
import { ArrowLeft } from 'lucide-react';

export default function BlogPage() {
  const handleBackHome = () => {
    window.location.href = '/';
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Back Button */}
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="container mx-auto px-4 py-4">
          <button
            onClick={handleBackHome}
            className="flex items-center gap-2 text-green-600 hover:text-green-700 font-semibold transition-colors"
          >
            <ArrowLeft size={20} />
            Voltar para Home
          </button>
        </div>
      </div>

      {/* Blog Content */}
      <BlogList />
    </div>
  );
}
