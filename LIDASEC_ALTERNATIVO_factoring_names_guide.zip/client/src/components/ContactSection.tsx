import ContactForm from './ContactForm';

export default function ContactSection() {
  return (
    <section id="contato" className="py-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Vamos Conversar?
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Estamos prontos para entender suas necessidades e oferecer as melhores soluções de factoring para seu negócio
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12 border border-gray-200">
          <ContactForm />
        </div>

        {/* Trust Badges */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div>
            <div className="text-4xl font-bold text-green-600 mb-2">100%</div>
            <p className="text-gray-600">Confidencialidade Garantida</p>
          </div>
          <div>
            <div className="text-4xl font-bold text-green-600 mb-2">24h</div>
            <p className="text-gray-600">Resposta em até 24 horas</p>
          </div>
          <div>
            <div className="text-4xl font-bold text-green-600 mb-2">500+</div>
            <p className="text-gray-600">Empresas Satisfeitas</p>
          </div>
        </div>
      </div>
    </section>
  );
}
