import { CheckCircle2 } from 'lucide-react';

const servicos = [
  {
    id: 1,
    title: 'Factoring Convencional',
    description: 'Compra de contas a receber com gestão completa de cobrança.',
    features: [
      'Antecipação de até 90% do valor',
      'Sem limite de operações',
      'Análise rápida de crédito',
      'Suporte personalizado',
    ],
  },
  {
    id: 2,
    title: 'Fomento Mercantil',
    description: 'Financiamento direto baseado em faturamento e fluxo de caixa.',
    features: [
      'Análise de faturamento',
      'Prazos flexíveis',
      'Sem garantias reais',
      'Aprovação em 48 horas',
    ],
  },
  {
    id: 3,
    title: 'Factoring Exportação',
    description: 'Soluções especializadas para empresas que exportam.',
    features: [
      'Cobertura internacional',
      'Proteção contra riscos',
      'Câmbio facilitado',
      'Expertise em comércio exterior',
    ],
  },
];

export default function ServicosSection() {
  const handleSolicitarOrcamento = () => {
    const contatoSection = document.getElementById('contato');
    if (contatoSection) {
      contatoSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="servicos" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Nossos Serviços
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Soluções de factoring e fomento mercantil adaptadas às necessidades do seu negócio
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {servicos.map((servico) => (
            <div
              key={servico.id}
              className="relative bg-white border-2 border-gray-200 rounded-2xl p-8 hover:border-green-600 hover:shadow-xl transition-all duration-300 group"
            >
              {/* Top Accent */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-green-600 to-yellow-400 rounded-t-2xl transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>

              {/* Number Badge */}
              <div className="absolute -top-4 -right-4 w-12 h-12 bg-gradient-to-br from-green-600 to-green-700 rounded-full flex items-center justify-center text-white font-bold shadow-lg">
                {servico.id}
              </div>

              {/* Content */}
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                {servico.title}
              </h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                {servico.description}
              </p>

              {/* Features */}
              <div className="space-y-3 mb-8">
                {servico.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>

              {/* CTA */}
              <button onClick={handleSolicitarOrcamento} className="w-full py-3 bg-gradient-to-r from-green-600 to-green-700 text-white font-bold rounded-lg hover:shadow-lg transition-all transform group-hover:scale-105">
                Solicitar Orçamento
              </button>
            </div>
          ))}
        </div>

        {/* Bottom Info */}
        <div className="mt-16 bg-gradient-to-r from-green-50 to-yellow-50 rounded-2xl p-8 md:p-12 border border-green-200">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Como funciona?
              </h3>
              <ol className="space-y-3 text-gray-700">
                <li className="flex gap-3">
                  <span className="font-bold text-green-600">1.</span>
                  <span>Envie seus documentos e informações de faturamento</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-green-600">2.</span>
                  <span>Nossa equipe analisa e aprova em até 48 horas</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-green-600">3.</span>
                  <span>Receba o capital de giro em sua conta</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-green-600">4.</span>
                  <span>Gerencie suas operações com suporte dedicado</span>
                </li>
              </ol>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Requisitos Básicos
              </h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span>Empresa registrada há mais de 6 meses</span>
                </li>
                <li className="flex gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span>Faturamento mensal mínimo</span>
                </li>
                <li className="flex gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span>Documentação fiscal em dia</span>
                </li>
                <li className="flex gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span>Contas a receber comprovadas</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
