import { Zap, Users, MapPin } from 'lucide-react';

const diferenciais = [
  {
    id: 1,
    icon: Zap,
    title: 'Recebível Futuro Imediato',
    description: 'Transforme suas contas a receber em capital de giro imediato, sem burocracia.',
    image: '/images/icon_speed.png',
  },
  {
    id: 2,
    icon: Users,
    title: 'Atendimento Personalizado',
    description: 'Equipe dedicada que entende os desafios únicos do seu negócio.',
    image: '/images/icon_personalized.png',
  },
  {
    id: 3,
    icon: MapPin,
    title: 'Proximidade ao Cliente',
    description: 'Presença local com expertise global para melhor atender sua empresa.',
    image: '/images/icon_proximity.png',
  },
];

export default function DiferenciaisSection() {
  const handleFaleComEspecialista = () => {
    const contatoSection = document.getElementById('contato');
    if (contatoSection) {
      contatoSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Por que escolher a lidasec?
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Três pilares que sustentam nossa excelência em factoring e fomento mercantil
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {diferenciais.map((diferencial) => {
            const IconComponent = diferencial.icon;
            return (
              <div
                key={diferencial.id}
                className="group relative bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-8 hover:shadow-xl transition-all duration-300 border border-gray-200 hover:border-green-400"
              >
                {/* Icon Container */}
                <div className="mb-6 relative">
                  <div className="w-20 h-20 bg-gradient-to-br from-green-600 to-green-700 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all">
                    <IconComponent className="w-10 h-10 text-yellow-400" />
                  </div>
                  <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-yellow-400 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {diferencial.title}
                </h3>
                <p className="text-gray-600 leading-relaxed mb-6">
                  {diferencial.description}
                </p>

                {/* Arrow */}
                <div className="flex items-center text-green-600 font-semibold group-hover:translate-x-2 transition-transform">
                  Saiba mais
                  <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>

                {/* Hover Background */}
                <div className="absolute inset-0 bg-gradient-to-br from-green-50 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10"></div>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <p className="text-gray-600 mb-6">
            Descubra como podemos acelerar o crescimento do seu negócio
          </p>
          <button onClick={handleFaleComEspecialista} className="px-8 py-4 bg-gradient-to-r from-green-600 to-green-700 text-white font-bold rounded-lg hover:shadow-lg transition-all transform hover:scale-105">
            Fale com um especialista
          </button>
        </div>
      </div>
    </section>
  );
}
