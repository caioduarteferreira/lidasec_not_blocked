import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { Link } from 'wouter';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleSaibaPlus = () => {
    const servicosSection = document.getElementById('servicos');
    if (servicosSection) {
      servicosSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const navItems = [
    { label: 'HOME', href: '/', isExternal: false },
    { label: 'SOBRE NÓS', href: '/about', isExternal: false },
    { label: 'INSTITUCIONAL', href: '#institucional', isExternal: true },
    { label: 'SERVIÇOS', href: '#servicos', isExternal: true },
    { label: 'BLOG', href: '/blog', isExternal: false },
    { label: 'CONTATO', href: '#contato', isExternal: true },
  ];

  const renderNavLink = (item: typeof navItems[0]) => {
    if (item.isExternal) {
      return (
        <a
          href={item.href}
          className="text-sm font-medium text-gray-700 hover:text-green-600 transition-colors"
        >
          {item.label}
        </a>
      );
    }
    return (
      <Link
        href={item.href}
        className="text-sm font-medium text-gray-700 hover:text-green-600 transition-colors"
      >
        {item.label}
      </Link>
    );
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity">
            <img 
              src="/images/lidasec_logo.png" 
              alt="lidasec" 
              className="h-16 w-auto object-contain"
            />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <div key={item.label}>
                {renderNavLink(item)}
              </div>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden md:flex items-center gap-4">
            <button onClick={handleSaibaPlus} className="px-6 py-2 bg-yellow-400 text-gray-900 font-semibold rounded-lg hover:bg-yellow-500 transition-colors">
              Saiba +
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden pb-4 flex flex-col gap-2">
            {navItems.map((item) => (
              <div
                key={item.label}
                onClick={() => setIsMenuOpen(false)}
              >
                {item.isExternal ? (
                  <a
                    href={item.href}
                    className="text-sm font-medium text-gray-700 hover:text-green-600 py-2 transition-colors block"
                  >
                    {item.label}
                  </a>
                ) : (
                  <Link
                    href={item.href}
                    className="text-sm font-medium text-gray-700 hover:text-green-600 py-2 transition-colors block"
                  >
                    {item.label}
                  </Link>
                )}
              </div>
            ))}
            <button className="mt-2 w-full px-6 py-2 bg-yellow-400 text-gray-900 font-semibold rounded-lg hover:bg-yellow-500 transition-colors">
              Saiba +
            </button>
          </nav>
        )}
      </div>
    </header>
  );
}
