import { useState } from 'react';
import { Mail, Phone, MapPin, CheckCircle2, AlertCircle, Upload, X } from 'lucide-react';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';

interface FormData {
  name: string;
  email: string;
  phone: string;
  company: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  phone?: string;
  company?: string;
  message?: string;
}

export default function ContactForm() {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    phone: '',
    company: '',
    message: '',
  });

  const [files, setFiles] = useState<File[]>([]);
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const createLeadMutation = trpc.leads.create.useMutation();
  const uploadDocumentMutation = trpc.leads.uploadDocument.useMutation();

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Nome é obrigatório';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email é obrigatório';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Email inválido';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Telefone é obrigatório';
    }

    if (!formData.company.trim()) {
      newErrors.company = 'Empresa é obrigatória';
    }

    if (!formData.message.trim()) {
      newErrors.message = 'Mensagem é obrigatória';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Mensagem deve ter pelo menos 10 caracteres';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({
        ...prev,
        [name]: undefined,
      }));
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newFiles = Array.from(e.target.files || []);
    setFiles(prev => [...prev, ...newFiles]);
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!validateForm()) {
      toast.error('Por favor, corrija os erros no formulário');
      return;
    }

    setIsSubmitting(true);

    try {
      // Criar o lead
      const leadResult = await createLeadMutation.mutateAsync({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        company: formData.company,
        message: formData.message,
      });

      if (!leadResult.success) {
        toast.error('Erro ao enviar formulário');
        setIsSubmitting(false);
        return;
      }

      const leadId = leadResult.leadId;

      // Upload de arquivos se houver
      if (files.length > 0) {
        for (const file of files) {
          const reader = new FileReader();
          reader.onload = async (event) => {
            try {
              const base64Data = (event.target?.result as string).split(',')[1];
              await uploadDocumentMutation.mutateAsync({
                leadId,
                fileName: file.name,
                fileData: base64Data,
                mimeType: file.type,
              });
            } catch (error) {
              console.error('Erro ao fazer upload do arquivo:', error);
              toast.error(`Erro ao fazer upload de ${file.name}`);
            }
          };
          reader.readAsDataURL(file);
        }
      }

      setSubmitSuccess(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        company: '',
        message: '',
      });
      setFiles([]);

      toast.success('Mensagem enviada com sucesso! Entraremos em contato em breve.');

      setTimeout(() => {
        setSubmitSuccess(false);
      }, 5000);
    } catch (error) {
      console.error('Erro ao enviar formulário:', error);
      toast.error('Erro ao enviar formulário. Tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
      {/* Contact Info */}
      <div className="space-y-8">
        <div>
          <h3 className="text-3xl font-bold text-gray-900 mb-2">Entre em Contato</h3>
          <p className="text-gray-600">
            Preencha o formulário ao lado e nossa equipe entrará em contato em breve para discutir as melhores soluções para seu negócio.
          </p>
        </div>

        <div className="space-y-6">
          {/* Phone */}
          <div className="flex gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-green-700 rounded-lg flex items-center justify-center flex-shrink-0">
              <Phone className="w-6 h-6 text-yellow-400" />
            </div>
            <div>
              <h4 className="font-bold text-gray-900 mb-1">Telefone</h4>
              <p className="text-gray-600">(47) 99717-6400</p>
              <p className="text-gray-600">(47) 99657-7856</p>
            </div>
          </div>

          {/* Email */}
          <div className="flex gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-green-700 rounded-lg flex items-center justify-center flex-shrink-0">
              <Mail className="w-6 h-6 text-yellow-400" />
            </div>
            <div>
              <h4 className="font-bold text-gray-900 mb-1">Email</h4>
              <p className="text-gray-600">contato@lidasec.com.br</p>
              <p className="text-gray-600">vendas@lidasec.com.br</p>
            </div>
          </div>

          {/* Location */}
          <div className="flex gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-green-700 rounded-lg flex items-center justify-center flex-shrink-0">
              <MapPin className="w-6 h-6 text-yellow-400" />
            </div>
            <div>
              <h4 className="font-bold text-gray-900 mb-1">Localização</h4>
              <p className="text-gray-600">Joinville - SC</p>
              <p className="text-gray-600">Brasil</p>
            </div>
          </div>
        </div>

        {/* Hours */}
        <div className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-lg p-6 border border-green-200">
          <h4 className="font-bold text-gray-900 mb-3">Horário de Funcionamento</h4>
          <div className="space-y-2 text-sm text-gray-700">
            <p>Segunda a Sexta: 08:00 - 18:00</p>
            <p>Sábado: 09:00 - 13:00</p>
            <p>Domingo: Fechado</p>
          </div>
        </div>
      </div>

      {/* Contact Form */}
      <div>
        {submitSuccess ? (
          <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-8 text-center h-full flex flex-col items-center justify-center">
            <CheckCircle2 className="w-16 h-16 text-green-600 mb-4" />
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Obrigado!</h3>
            <p className="text-gray-700 mb-4">
              Sua mensagem foi enviada com sucesso. Nossa equipe entrará em contato em breve.
            </p>
            <button
              onClick={() => setSubmitSuccess(false)}
              className="text-green-600 font-semibold hover:text-green-700"
            >
              Enviar outra mensagem
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Name */}
            <div>
              <label htmlFor="name" className="block text-sm font-semibold text-gray-900 mb-2">
                Nome Completo *
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Seu nome"
                className={`w-full px-4 py-3 rounded-lg border-2 transition-colors ${
                  errors.name
                    ? 'border-red-500 bg-red-50 focus:border-red-600'
                    : 'border-gray-200 bg-white focus:border-green-600'
                } focus:outline-none`}
              />
              {errors.name && (
                <p className="text-red-600 text-sm mt-1 flex items-center gap-1">
                  <AlertCircle size={16} /> {errors.name}
                </p>
              )}
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-semibold text-gray-900 mb-2">
                Email *
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="seu.email@empresa.com"
                className={`w-full px-4 py-3 rounded-lg border-2 transition-colors ${
                  errors.email
                    ? 'border-red-500 bg-red-50 focus:border-red-600'
                    : 'border-gray-200 bg-white focus:border-green-600'
                } focus:outline-none`}
              />
              {errors.email && (
                <p className="text-red-600 text-sm mt-1 flex items-center gap-1">
                  <AlertCircle size={16} /> {errors.email}
                </p>
              )}
            </div>

            {/* Phone */}
            <div>
              <label htmlFor="phone" className="block text-sm font-semibold text-gray-900 mb-2">
                Telefone *
              </label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="(47) 99999-9999"
                className={`w-full px-4 py-3 rounded-lg border-2 transition-colors ${
                  errors.phone
                    ? 'border-red-500 bg-red-50 focus:border-red-600'
                    : 'border-gray-200 bg-white focus:border-green-600'
                } focus:outline-none`}
              />
              {errors.phone && (
                <p className="text-red-600 text-sm mt-1 flex items-center gap-1">
                  <AlertCircle size={16} /> {errors.phone}
                </p>
              )}
            </div>

            {/* Company */}
            <div>
              <label htmlFor="company" className="block text-sm font-semibold text-gray-900 mb-2">
                Empresa *
              </label>
              <input
                type="text"
                id="company"
                name="company"
                value={formData.company}
                onChange={handleChange}
                placeholder="Nome da sua empresa"
                className={`w-full px-4 py-3 rounded-lg border-2 transition-colors ${
                  errors.company
                    ? 'border-red-500 bg-red-50 focus:border-red-600'
                    : 'border-gray-200 bg-white focus:border-green-600'
                } focus:outline-none`}
              />
              {errors.company && (
                <p className="text-red-600 text-sm mt-1 flex items-center gap-1">
                  <AlertCircle size={16} /> {errors.company}
                </p>
              )}
            </div>

            {/* Message */}
            <div>
              <label htmlFor="message" className="block text-sm font-semibold text-gray-900 mb-2">
                Mensagem *
              </label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                placeholder="Conte-nos sobre suas necessidades..."
                rows={5}
                className={`w-full px-4 py-3 rounded-lg border-2 transition-colors resize-none ${
                  errors.message
                    ? 'border-red-500 bg-red-50 focus:border-red-600'
                    : 'border-gray-200 bg-white focus:border-green-600'
                } focus:outline-none`}
              />
              {errors.message && (
                <p className="text-red-600 text-sm mt-1 flex items-center gap-1">
                  <AlertCircle size={16} /> {errors.message}
                </p>
              )}
            </div>

            {/* File Upload */}
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">
                Documentos (Opcional)
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-green-500 transition">
                <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                <p className="text-sm text-gray-600 mb-2">Arraste arquivos aqui ou clique para selecionar</p>
                <input
                  type="file"
                  multiple
                  onChange={handleFileChange}
                  className="hidden"
                  id="file-input"
                  accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.png"
                />
                <label htmlFor="file-input" className="inline-block">
                  <button
                    type="button"
                    onClick={() => document.getElementById('file-input')?.click()}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition cursor-pointer"
                  >
                    Selecionar Arquivos
                  </button>
                </label>
              </div>

              {/* File List */}
              {files.length > 0 && (
                <div className="mt-4 space-y-2">
                  <p className="text-sm font-medium text-gray-700">Arquivos selecionados:</p>
                  {files.map((file, index) => (
                    <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                      <span className="text-sm text-gray-700">{file.name}</span>
                      <button
                        type="button"
                        onClick={() => removeFile(index)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-gradient-to-r from-green-600 to-green-700 text-white font-bold rounded-lg hover:shadow-lg transition-all transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
            >
              {isSubmitting ? 'Enviando...' : 'Enviar Mensagem'}
            </button>

            <p className="text-xs text-gray-500 text-center">
              * Campos obrigatórios. Seus dados serão mantidos em sigilo.
            </p>
          </form>
        )}
      </div>
    </div>
  );
}
