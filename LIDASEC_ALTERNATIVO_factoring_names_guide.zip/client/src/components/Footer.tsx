import { Mail, Phone, MapPin, Facebook, Linkedin, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      {/* CTA Section */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Pronto para crescer?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Entre em contato com nossos especialistas e descubra como podemos impulsionar seu negócio
          </p>
          <button className="px-8 py-4 bg-yellow-400 text-gray-900 font-bold rounded-lg hover:bg-yellow-500 transition-colors shadow-lg">
            Solicitar Contato
          </button>
        </div>
      </div>

      {/* Main Footer */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-green-600 to-green-700 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">LS</span>
              </div>
              <span className="font-bold text-white text-lg">lidasec</span>
            </div>
            <p className="text-sm text-gray-400 mb-4">
              Soluções de factoring e fomento mercantil para empresas que desejam crescer.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-white mb-4">Links Rápidos</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#home" className="text-gray-400 hover:text-white transition-colors">Home</a></li>
              <li><a href="#institucional" className="text-gray-400 hover:text-white transition-colors">Institucional</a></li>
              <li><a href="#servicos" className="text-gray-400 hover:text-white transition-colors">Serviços</a></li>
              <li><a href="#contato" className="text-gray-400 hover:text-white transition-colors">Contato</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-bold text-white mb-4">Serviços</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Factoring Convencional</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Fomento Mercantil</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Factoring Exportação</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Consultoria</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-bold text-white mb-4">Contato</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex gap-2">
                <Phone size={16} className="text-green-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-400">(47) 99717-6400</span>
              </li>
              <li className="flex gap-2">
                <Mail size={16} className="text-green-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-400">contato@lidasec.com.br</span>
              </li>
              <li className="flex gap-2">
                <MapPin size={16} className="text-green-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-400">Joinville - SC</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-800 pt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-400">
            <div>
              <p>&copy; 2024 lidasec. Todos os direitos reservados.</p>
            </div>
            <div className="md:text-right space-x-4">
              <a href="#" className="hover:text-white transition-colors">Política de Privacidade</a>
              <a href="#" className="hover:text-white transition-colors">Termos de Uso</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
