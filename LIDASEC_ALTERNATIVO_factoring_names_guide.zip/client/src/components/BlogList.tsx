import { blogArticles, getCategories } from '@/data/blogArticles';
import { useState } from 'react';
import { Calendar, Clock, Tag } from 'lucide-react';
import { Link } from 'wouter';

export default function BlogList() {
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const categories = getCategories();

  const filteredArticles = selectedCategory
    ? blogArticles.filter((article) => article.category === selectedCategory)
    : blogArticles;

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-5xl font-bold mb-4">Blog lidasec</h1>
          <p className="text-xl text-green-100 max-w-2xl">
            Artigos educativos sobre factoring, fomento mercantil e gestão financeira para impulsionar seu negócio
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar - Categories */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-20">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Categorias</h3>
              <div className="space-y-2">
                <button
                  onClick={() => setSelectedCategory('')}
                  className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                    selectedCategory === ''
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Todos os Artigos
                </button>
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                      selectedCategory === category
                        ? 'bg-green-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>

              {/* Search Stats */}
              <div className="mt-6 pt-6 border-t border-gray-200">
                <p className="text-sm text-gray-600">
                  <span className="font-bold text-green-600">{filteredArticles.length}</span> artigo(s) encontrado(s)
                </p>
              </div>
            </div>
          </div>

          {/* Main Content - Articles */}
          <div className="lg:col-span-3">
            {filteredArticles.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-600 text-lg">Nenhum artigo encontrado nesta categoria.</p>
              </div>
            ) : (
              <div className="space-y-6">
                {filteredArticles.map((article) => (
                  <Link key={article.id} href={`/blog/${article.slug}`}>
                    <div className="group bg-white rounded-lg shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer border border-gray-200 hover:border-green-400">
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-0">
                        {/* Image */}
                        <div className="md:col-span-1 h-48 md:h-auto overflow-hidden bg-gray-200">
                          <img
                            src={article.image}
                            alt={article.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>

                        {/* Content */}
                        <div className="md:col-span-3 p-6 flex flex-col justify-between">
                          <div>
                            <div className="flex items-center gap-3 mb-3">
                              <span className="inline-block px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full">
                                {article.category}
                              </span>
                              <span className="text-sm text-gray-500 flex items-center gap-1">
                                <Clock size={14} />
                                {article.readTime} min de leitura
                              </span>
                            </div>

                            <h2 className="text-2xl font-bold text-gray-900 mb-2 group-hover:text-green-600 transition-colors">
                              {article.title}
                            </h2>

                            <p className="text-gray-600 mb-4 line-clamp-2">{article.excerpt}</p>
                          </div>

                          <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                              <span className="flex items-center gap-1">
                                <Calendar size={14} />
                                {formatDate(article.date)}
                              </span>
                              <span>Por {article.author}</span>
                            </div>

                            <button className="text-green-600 font-semibold group-hover:text-green-700 flex items-center gap-2">
                              Ler Artigo
                              <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                              </svg>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Pronto para transformar seu negócio?</h2>
          <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto">
            Conheça nossas soluções de factoring e fomento mercantil
          </p>
          <a href="/#contato" className="inline-block px-8 py-4 bg-yellow-400 text-gray-900 font-bold rounded-lg hover:bg-yellow-500 transition-colors">
            Solicitar Contato
          </a>
        </div>
      </div>
    </div>
  );
}
