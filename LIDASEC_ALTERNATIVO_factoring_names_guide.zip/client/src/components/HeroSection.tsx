export default function HeroSection() {
  const handleSaibaMais = () => {
    const servicosSection = document.getElementById('servicos');
    if (servicosSection) {
      servicosSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleContato = () => {
    const contatoSection = document.getElementById('contato');
    if (contatoSection) {
      contatoSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Background Image */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: 'url(/images/hero_background.png)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed',
        }}
      >
        <div className="absolute inset-0 bg-black/40"></div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-white space-y-6">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold leading-tight">
                Credibilidade para seu negócio
              </h1>
              <p className="text-xl md:text-2xl font-light text-gray-100">
                Soluções de factoring e fomento mercantil que impulsionam o crescimento da sua empresa.
              </p>
            </div>

            <p className="text-lg text-gray-200 max-w-lg">
              Característica de quem consegue ou conquista a confiança de alguém — que possui crédito. Transformamos suas contas a receber em capital de giro imediato.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button onClick={handleSaibaMais} className="px-8 py-4 bg-yellow-400 text-gray-900 font-bold rounded-lg hover:bg-yellow-500 transition-all transform hover:scale-105 shadow-lg">
                Saiba Mais
              </button>
              <button onClick={handleContato} className="px-8 py-4 bg-white/20 text-white font-bold rounded-lg hover:bg-white/30 transition-all border border-white/50 backdrop-blur-sm">
                Contato
              </button>
            </div>
          </div>

          {/* Right Decorative Element */}
          <div className="hidden md:flex justify-center items-center">
            <div className="relative w-80 h-80">
              <div className="absolute inset-0 bg-gradient-to-br from-yellow-400/30 to-green-600/30 rounded-full blur-3xl"></div>
              <div className="absolute inset-0 border-2 border-white/20 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
        <div className="text-white text-center">
          <p className="text-sm mb-2">Conheça nossos serviços</p>
          <svg className="w-6 h-6 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </div>
    </section>
  );
}
