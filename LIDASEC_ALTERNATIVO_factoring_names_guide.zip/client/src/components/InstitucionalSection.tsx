export default function InstitucionalSection() {
  const handleConhecerMais = () => {
    window.location.href = '/about';
  };

  return (
    <section id="institucional" className="py-20 bg-gradient-to-br from-green-50 to-gray-50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Left Image */}
          <div className="relative h-96 md:h-full rounded-2xl overflow-hidden shadow-xl">
            <img
              src="/images/section_business.png"
              alt="Equipe lidasec"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
          </div>

          {/* Right Content */}
          <div className="space-y-6">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Sobre a lidasec
              </h2>
              <div className="w-16 h-1 bg-gradient-to-r from-green-600 to-yellow-400"></div>
            </div>

            <p className="text-lg text-gray-700 leading-relaxed">
              A lidasec é uma empresa especializada em factoring e fomento mercantil, dedicada a oferecer soluções financeiras inovadoras para empresas de todos os portes.
            </p>

            <p className="text-lg text-gray-700 leading-relaxed">
              Com uma equipe de profissionais experientes e comprometidos, trabalhamos para transformar as contas a receber de nossos clientes em oportunidades de crescimento imediato.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 py-8 border-t border-b border-gray-200">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-1">500+</div>
                <p className="text-sm text-gray-600">Clientes Ativos</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-1">R$ 50M+</div>
                <p className="text-sm text-gray-600">Capital Operacional</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-1">15+</div>
                <p className="text-sm text-gray-600">Anos de Experiência</p>
              </div>
            </div>

            <p className="text-gray-700">
              Nossa missão é ser o parceiro financeiro de confiança que impulsiona o crescimento sustentável dos negócios através de soluções de factoring ágeis, transparentes e personalizadas.
            </p>

            <button onClick={handleConhecerMais} className="px-8 py-3 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700 transition-colors">
              Conhecer Mais
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
