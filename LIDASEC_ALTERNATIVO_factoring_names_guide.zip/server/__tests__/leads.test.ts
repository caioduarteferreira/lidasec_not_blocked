import { describe, it, expect, beforeEach, vi } from 'vitest';
import { createLead, getLead, getAllLeads, updateLeadStatus, createDocument, getDocumentsByLeadId } from '../db';

// Mock do banco de dados
vi.mock('../db', async () => {
  const actual = await vi.importActual('../db');
  return {
    ...actual,
    createLead: vi.fn(),
    getLead: vi.fn(),
    getAllLeads: vi.fn(),
    updateLeadStatus: vi.fn(),
    createDocument: vi.fn(),
    getDocumentsByLeadId: vi.fn(),
  };
});

describe('Leads Management', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('createLead', () => {
    it('deve criar um novo lead com dados válidos', async () => {
      const leadData = {
        name: 'João Silva',
        email: 'joao@example.com',
        phone: '(47) 99999-9999',
        company: 'Tech Company',
        message: 'Gostaria de conhecer seus serviços',
        status: 'novo' as const,
      };

      vi.mocked(createLead).mockResolvedValueOnce({ insertId: 1 } as any);

      const result = await createLead(leadData);
      
      expect(result).toBeDefined();
      expect(createLead).toHaveBeenCalledWith(leadData);
    });

    it('deve validar campos obrigatórios', async () => {
      const invalidLead = {
        name: '',
        email: 'invalid-email',
        phone: '',
        company: '',
        message: '',
        status: 'novo' as const,
      };

      expect(() => {
        if (!invalidLead.name) throw new Error('Nome é obrigatório');
        if (!invalidLead.email) throw new Error('Email é obrigatório');
      }).toThrow();
    });
  });

  describe('getLead', () => {
    it('deve retornar um lead pelo ID', async () => {
      const mockLead = {
        id: 1,
        name: 'João Silva',
        email: 'joao@example.com',
        phone: '(47) 99999-9999',
        company: 'Tech Company',
        message: 'Gostaria de conhecer seus serviços',
        status: 'novo',
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      vi.mocked(getLead).mockResolvedValueOnce(mockLead);

      const result = await getLead(1);
      
      expect(result).toEqual(mockLead);
      expect(getLead).toHaveBeenCalledWith(1);
    });

    it('deve retornar undefined se lead não existir', async () => {
      vi.mocked(getLead).mockResolvedValueOnce(undefined);

      const result = await getLead(999);
      
      expect(result).toBeUndefined();
    });
  });

  describe('getAllLeads', () => {
    it('deve retornar lista de todos os leads', async () => {
      const mockLeads = [
        {
          id: 1,
          name: 'João Silva',
          email: 'joao@example.com',
          phone: '(47) 99999-9999',
          company: 'Tech Company',
          message: 'Mensagem 1',
          status: 'novo',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          id: 2,
          name: 'Maria Santos',
          email: 'maria@example.com',
          phone: '(47) 98888-8888',
          company: 'Another Company',
          message: 'Mensagem 2',
          status: 'contatado',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];

      vi.mocked(getAllLeads).mockResolvedValueOnce(mockLeads);

      const result = await getAllLeads();
      
      expect(result).toHaveLength(2);
      expect(result).toEqual(mockLeads);
    });

    it('deve retornar array vazio se não houver leads', async () => {
      vi.mocked(getAllLeads).mockResolvedValueOnce([]);

      const result = await getAllLeads();
      
      expect(result).toEqual([]);
    });
  });

  describe('updateLeadStatus', () => {
    it('deve atualizar o status de um lead', async () => {
      vi.mocked(updateLeadStatus).mockResolvedValueOnce(undefined);

      await updateLeadStatus(1, 'contatado');
      
      expect(updateLeadStatus).toHaveBeenCalledWith(1, 'contatado');
    });

    it('deve aceitar status válidos', async () => {
      const validStatuses = ['novo', 'contatado', 'convertido', 'descartado'];
      
      for (const status of validStatuses) {
        vi.mocked(updateLeadStatus).mockResolvedValueOnce(undefined);
        await updateLeadStatus(1, status);
        expect(updateLeadStatus).toHaveBeenCalledWith(1, status);
      }
    });
  });

  describe('Document Management', () => {
    describe('createDocument', () => {
      it('deve criar um novo documento associado a um lead', async () => {
        const documentData = {
          leadId: 1,
          fileName: 'proposta.pdf',
          fileKey: 'leads/1/1234567890-proposta.pdf',
          fileUrl: 'https://s3.example.com/leads/1/1234567890-proposta.pdf',
          mimeType: 'application/pdf',
          fileSize: 102400,
        };

        vi.mocked(createDocument).mockResolvedValueOnce({ insertId: 1 } as any);

        const result = await createDocument(documentData);
        
        expect(result).toBeDefined();
        expect(createDocument).toHaveBeenCalledWith(documentData);
      });
    });

    describe('getDocumentsByLeadId', () => {
      it('deve retornar documentos de um lead específico', async () => {
        const mockDocuments = [
          {
            id: 1,
            leadId: 1,
            fileName: 'proposta.pdf',
            fileKey: 'leads/1/1234567890-proposta.pdf',
            fileUrl: 'https://s3.example.com/leads/1/1234567890-proposta.pdf',
            mimeType: 'application/pdf',
            fileSize: 102400,
            createdAt: new Date(),
          },
        ];

        vi.mocked(getDocumentsByLeadId).mockResolvedValueOnce(mockDocuments);

        const result = await getDocumentsByLeadId(1);
        
        expect(result).toHaveLength(1);
        expect(result[0].leadId).toBe(1);
      });

      it('deve retornar array vazio se não houver documentos', async () => {
        vi.mocked(getDocumentsByLeadId).mockResolvedValueOnce([]);

        const result = await getDocumentsByLeadId(999);
        
        expect(result).toEqual([]);
      });
    });
  });
});
