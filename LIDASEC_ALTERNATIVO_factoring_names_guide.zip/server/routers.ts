import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { createLead, createDocument, getDocumentsByLeadId, getAllLeads } from "./db";
import { storagePut } from "./storage";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Procedimentos para leads e documentos
  leads: router({
    create: publicProcedure
      .input(z.object({
        name: z.string().min(1, "Nome é obrigatório"),
        email: z.string().email("Email inválido"),
        phone: z.string().min(1, "Telefone é obrigatório"),
        company: z.string().min(1, "Empresa é obrigatória"),
        message: z.string().min(1, "Mensagem é obrigatória"),
      }))
      .mutation(async ({ input }) => {
        const result = await createLead({
          name: input.name,
          email: input.email,
          phone: input.phone,
          company: input.company,
          message: input.message,
          status: "novo",
        });
        
        return {
          success: true,
          leadId: (result as any).insertId || 0,
        };
      }),

    getAll: publicProcedure.query(async () => {
      return await getAllLeads();
    }),

    uploadDocument: publicProcedure
      .input(z.object({
        leadId: z.number(),
        fileName: z.string(),
        fileData: z.string(), // Base64 encoded file data
        mimeType: z.string(),
      }))
      .mutation(async ({ input }) => {
        try {
          // Converter base64 para buffer
          const buffer = Buffer.from(input.fileData, 'base64');
          
          // Gerar chave única para o arquivo
          const fileKey = `leads/${input.leadId}/${Date.now()}-${input.fileName}`;
          
          // Upload para S3
          const { url } = await storagePut(fileKey, buffer, input.mimeType);
          
          // Salvar metadados no banco de dados
          await createDocument({
            leadId: input.leadId,
            fileName: input.fileName,
            fileKey: fileKey,
            fileUrl: url,
            mimeType: input.mimeType,
            fileSize: buffer.length,
          });
          
          return {
            success: true,
            url: url,
            fileKey: fileKey,
          };
        } catch (error) {
          console.error("Erro ao fazer upload do arquivo:", error);
          throw new Error("Falha ao fazer upload do arquivo");
        }
      }),

    getDocuments: publicProcedure
      .input(z.object({
        leadId: z.number(),
      }))
      .query(async ({ input }) => {
        return await getDocumentsByLeadId(input.leadId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
